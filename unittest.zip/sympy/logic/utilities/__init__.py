from .dimacs import load_file
